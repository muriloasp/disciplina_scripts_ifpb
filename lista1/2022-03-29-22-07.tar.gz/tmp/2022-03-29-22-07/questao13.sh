#!/bin/bash

echo $( python3 -c "print($1 + $2 + $3)" )
