#!/bin/bash
echo "At the end of the storm there is a golden sky"
