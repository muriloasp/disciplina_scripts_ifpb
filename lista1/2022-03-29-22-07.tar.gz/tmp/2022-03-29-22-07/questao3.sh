#!/bin/bash

dir1=$1
dir2=$2

echo -e "\nConteúdo de ${dir1}:"
ls ${dir1}

echo -e "\nConteúdo de ${dir2}:"
ls ${dir2}
