#!/bin/bash

read -p 'Digite um número inteiro: ' y
y=$((y + 1))
echo ${y}
